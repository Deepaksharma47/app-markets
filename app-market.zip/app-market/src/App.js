// import logo from './logo.svg';

import './App.css';
import Achievments from './components/Achievments';
import Download from './components/Download';
import Footer from './components/Footer';
import Navbar from './components/Navbar';
import Porfolio from './components/Porfolio';
import Services from './components/Services';
import WhyUs from './components/WhyUs';

function App() {
  return (
    <div className="App">
      <Navbar/>
      <Download/>
      <Services/>
      <WhyUs/>
      <Achievments/>
      <Porfolio/>
      <Footer/>

    </div>
  );
}

export default App;
