import React from 'react'
import phoneimage from "../images/combine_phone.png"

import { MdFileDownload } from "react-icons/md";
import { FaLongArrowAltRight } from "react-icons/fa";


const Download = () => {
  return (
    <section className='download-com '>
        <div className='bg-A bg-opacity-10 h-100'>
        <div className='container '>
            <div className='row  align-items-center mx-auto py-5'>
                <div className='col-xl-5  col-md-12 '>
                    <div className='row text-start'>
                        <div className='col-12 fw-semibold text-white fs-1 my-3'>We Create Applications With Excellent Technology.</div>
                        <div className='col-12 text-white download-smalltext my-3 text-wrap fs-6'>It Is A Long Established Fact That A Reader Will Be Distracted By The Readable Content Of A Page When Looking At Its Layout. The Point Of Using Lorem Ipsum Is That It Has A More-Or-Less Normal Distribution Of Letters, As Opposed To Using 'Content </div>
                        <div className='col-12 my-3'>
                            <div className='row'>
                                <div className='col-lg-4 col-sm-12'>
                                    <button  class="btn btn-light text-nowrap fw-semibold">Download Now <MdFileDownload /></button>
                                </div>
                                <div className='col-lg-4 col-sm-12'>
                                <button  class="btn text-white text-nowrap fw-semibold">Explore More <FaLongArrowAltRight /></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className='col-xl-6 w-60 ms-auto  col-md-12 '>
                <img src={phoneimage} className="img-fluid"  />
                </div>

            </div>
        </div>
        </div>
    </section>
    
  )
}

export default Download