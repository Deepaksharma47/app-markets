import React from "react";
import checkcirle from "../images/check_circle.png";
import assignmenttured from "../images/assignment_turned.png";
import supervised from "../images/supervised_user.png";

const Achievments = () => {
  return (
    <section className="bg-light">
      <div className="container py-5">
        <div className="row">
          <div className="col-xl-6 col-12 fs-2 fw-bold mx-auto">
            We Completed 1200+ Projects Yearly Successfully & Counting
          </div>
        </div>
        <div className="row">
          <div className="row justify-content-center my-3">
            <div className="col-xl-7 fw-semibold text-muted col-sm-12 mx-auto">
              It Is A Long Established Fact That A Reader Will Be Distracted By
              The Readable Content Of A Page When Looking At Its Layout.
            </div>
          </div>
        </div>
        <div className="row py-5 mx-auto justify-content-evenly">
          <div className="col-xl-3 col-6 my-2 ">
            <div className="row align-items-center">
              <div className="col-3">
                <img src={checkcirle} alt=".." className="img-fluid" />
              </div>
              <div className="col-9 ">
                <div className="row text-primary fw-bold fs-5">100+</div>
                <div className="row fw-semibold fs-6 text-primary text-nowrap">Projects Complete</div>
              </div>
            </div>
          </div>
          <div className="col-xl-3 col-6 my-2">
          <div className="row align-items-center">
              <div className="col-3">
                <img src={assignmenttured} alt=".." className="img-fluid" />
              </div>
              <div className="col-9 ">
                <div className="row text-primary fw-bold fs-5">100+</div>
                <div className="row fw-semibold fs-6">Active Projects</div>
              </div>
            </div>
               </div>
          <div className="col-xl-3 col-6 my-2">
          <div className="row align-items-center">
              <div className="col-3">
                <img src={supervised} alt=".." className="img-fluid" />
              </div>
              <div className="col-9 ">
                <div className="row text-primary fw-bold fs-5">90+</div>
                <div className="row fw-semibold fs-6">Client Satisfied</div>
              </div>
            </div>
             </div>
          <div className="col-xl-3 col-6 my-2">
          <div className="row align-items-center">
              <div className="col-3">
                <img src={supervised} alt=".." className="img-fluid" />
              </div>
              <div className="col-9 ">
                <div className="row text-primary fw-bold fs-5">56+</div>
                <div className="row fw-semibold fs-6">Country Available</div>
              </div>
            </div>
              </div>
        </div>
      </div>
    </section>
  );
};

export default Achievments;
