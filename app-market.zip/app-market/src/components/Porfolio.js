import React from "react";
import iphone1 from "../images/iphone1.png"
import iphone2 from "../images/iphone2.png"
import iphone3 from "../images/iphone3.png"

const Porfolio = () => {
  return (
    <section className="bg-light">
      <div className="container py-3">
        <div className="row">
          <div className="col-xl-6 col-12 fs-2 fw-bold mx-auto">
            Our Portfolio
          </div>
        </div>
        <div className="row">
          <div className="row justify-content-center my-3">
            <div className="col-xl-7 fw-semibold text-muted col-sm-12 mx-auto">
            It Is A Long Established Fact That A Reader Will Be Distracted By The Readable Content Of A Page When Looking At Its Layout. The Point Of Using Lorem 
            </div>
          </div>
        </div>   

        <div className="row">
            <div className="col-xl-3 col-12">
                <img src={iphone1} className="img-fluid" alt="..."/>
            </div>
            <div className="col-xl-3 col-12">
                <img src={iphone2} className="img-fluid" alt="..."/>
            </div>
            <div className="col-xl-3 col-12">
                <img src={iphone3} className="img-fluid" alt="..."/>
            </div>
            <div className="col-xl-3 col-12">
                <img src={iphone3} className="img-fluid" alt="..."/>
            </div>
        </div>  
    </div>   
    </section>
  );
};

export default Porfolio;
