import React from "react";

import phone from "../images/UniqueApp.png";
import dashboard from "../images/Dashboard.png";
import constructionimg from "../images/Construction.png";

const Services = () => {
  return (
    <section className="bg-light service-section">
      <div className="container service-container">
        <div className="row ">
          <div className="col-xl-4 col-sm-12 fs-2 fw-bold mx-auto my-3">
            We provide various kind of service for you
          </div>
        </div>
        <div className="row">
          <div className="col-lg-6 fw-semibold text-muted col-sm-12 mx-auto">
            It Is A Long Established Fact That A Reader Will Be Distracted By
            The Readable Content Of A Page When Looking At Its Layout. The Point
            Of Using Lorem
          </div>
        </div>
        <div className="row mt-5 mx-auto justify-content-evenly ">
          <div className="card col-8 col-lg-3  border-0 my-5 px-3 rounded-3">
            <img src={phone} className="card-img-top" alt="..." />
            <div className="card-body">
              <div className="card-title fw-bold fs-4">Unique App Ui</div>
              <p className="fw-semibold text-muted">
              It Is A Long Established Fact That A Reader Will Be Distracted By The Readable Content Of A Page
              </p>
            </div>
          </div>
          <div className="card col-8 col-lg-3  border-0 my-5 px-3 rounded-3">
            <img src={dashboard} className="card-img-top" alt="..." />
            <div className="card-body">
            <div className="card-title fw-bold fs-4">Exclient Dashboard</div>
            <p className="fw-semibold text-muted">
            It Is A Long Established Fact That A Reader Will Be Distracted By The Readable Content Of A Page
              </p>
            </div>
          </div>
          <div className="card col-8 col-lg-3  border-0 my-5 px-3 rounded-3">
            <img src={constructionimg} className="card-img-top" alt="..."  />
            <div className="card-body">
            <div className="card-title fw-bold fs-4">By Construction</div>
            <p className="fw-semibold text-muted">
            It Is A Long Established Fact That A Reader Will Be Distracted By The Readable Content Of A Page
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;
