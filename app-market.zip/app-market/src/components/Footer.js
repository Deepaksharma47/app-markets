import React from 'react'
import pixbey from "../images/Group 50.png"
import { FaInstagram } from "react-icons/fa";
import { FaTwitter } from "react-icons/fa6";
import { FaLinkedinIn } from "react-icons/fa";
import { FaFacebook } from "react-icons/fa";

const Footer = () => {
  return (
    <section className='bg-secondary'>
        <div className='container py-5'>
            <div className='row mx-auto my-3'>
                <div className='col-xl-3 col-12'>
                    <div className='row gap-3'>
                        <img src={pixbey} className='img-fluid col-6' alt='...'/>
                        <div className='col-12'>
                            <div className='row justify-content-start'>
                                <div className='col-2'>  <FaInstagram/></div>
                                <div className='col-2'>  <FaTwitter/></div>
                                <div className='col-2'>  <FaLinkedinIn/></div>
                                <div className='col-2'>    <FaFacebook/></div>
                            </div>
                        </div>
                    </div>

                </div>
                <div className='col-xl-3 col-12  text-start fw-semibold'>
                    <div className='row gap-1'>
                        <div className='fw-bold'>Link</div>
                        <div>Home</div>
                        <div>Pricing</div>
                        <div>Download</div>
                        <div>About</div>
                        <div>Service</div>
                    </div>
                </div>
                <div className='col-xl-3 col-12 text-start fw-semibold'>
                <div className='row gap-1'>
                        <div className='fw-bold'>Support</div>
                        <div>FAQ</div>
                        <div>How it</div>
                        <div>Feature</div>
                        <div>Contact</div>
                        <div>Reporting</div>
                    </div>
                </div>
                <div className='col-xl-3 col-12 text-start fw-semibold'>
                <div className='row gap-1'>
                        <div className='fw-bold'>Contact Us</div>
                        <div>+8695554852</div>
                        <div>ds9999106554@gmail.com</div>
                        <div>Dehradun city</div>
                    </div>
                </div>
            </div>
            <div className='row justify-content-between  border-top py-3'>
                <div className='col-3'>
                    Copyright & Design by Deepak sharma
                </div>
                <div className='col-3'>
                    Term of use   |  Privacy Policy
                </div>
            </div>
        </div>
    </section>
  )
}

export default Footer